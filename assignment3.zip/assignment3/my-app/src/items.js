const items = [
    {
        id: 1,
        name: 'Udin',
        power: '1000'
    },
    {
        id: 2,
        name: 'Bambang',
        power: '1200'
    },
    {
        id: 3,
        name: 'Sedunia',
        power: '1300'
    }
]

export default items
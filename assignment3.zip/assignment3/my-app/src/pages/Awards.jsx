const Awards = () => {
    return (
        <div id="awards" className="content">
            <h1>Awards</h1>
            <ol class="list">
                <li class="list-item one"><span>Best employee of 2018</span></li>
                <li class="list-item two"><span>C# development</span></li>
                <li class="list-item three"><span>Sharepoint</span></li>
                <li class="list-item four"><span>Dynamic 365</span></li>
            </ol>
        </div>
    )
}

export default Awards
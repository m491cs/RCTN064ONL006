
const Experience = () => {
    return (
        <div id="experience" className="content">
            <h1>Experience</h1>
            <br/><br/>
            <p>Test Subject (during her first years, formerly)</p>
            <p>Student at Eden Academy</p>
        </div>
    )
}

export default Experience
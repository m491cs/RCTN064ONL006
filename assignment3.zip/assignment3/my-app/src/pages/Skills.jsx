
const Skills = () => {
    return (
        <div id="skills" className="content">
            <h1>Skills</h1>
                        
<ol class="list">
    <li class="list-item one"><span>HTML5</span></li>
    <li class="list-item two"><span>React Native</span></li>
    <li class="list-item three"><span>PHP</span></li>
    <li class="list-item four"><span>Git Hub</span></li>
</ol>
    

        </div>
    )
}

export default Skills